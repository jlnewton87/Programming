$(document).ready(function(){

$('.link').gxInit({queue: 'cancel'});

	$('.link').hover(function () {
		$('.link').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
$('.link1').gxInit({queue: 'cancel'});

	$('.link1').hover(function () {
		$('.link1').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link1').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
$('.link2').gxInit({queue: 'cancel'});

	$('.link2').hover(function () {
		$('.link2').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link2').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
$('.link3').gxInit({queue: 'cancel'});

	$('.link3').hover(function () {
		$('.link3').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link3').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});

$('.link4').gxInit({queue: 'cancel'});

	$('.link4').hover(function () {
		$('.link4').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link4').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
		
$('.link5').gxInit({queue: 'cancel'});

	$('.link5').hover(function () {
		$('.link5').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link5').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
		
$('.link6').gxInit({queue: 'cancel'});

	$('.link6').hover(function () {
		$('.link6').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link6').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});	

$('.link7').gxInit({queue: 'cancel'});

	$('.link7').hover(function () {
		$('.link7').gx({'color': '#B50507', 'background-color': 'black'}, 'fast', 'Linear');
	}, function() {
		$('.link7').gx({'color':'black', 'background-color':'#B50507'}, 'fast', 'Linear')
		});
	 });