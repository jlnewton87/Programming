﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtlantaRentals.Models
{
    public class BranchPhone
    {
        public int BranchId { get; set; }
        public string PhoneNumber { get; set; }
    }
}
